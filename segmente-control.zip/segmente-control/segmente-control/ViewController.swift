//
//  ViewController.swift
//  segmente-control
//
//  Created by MAC on 25/06/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
// 205730694012

import UIKit

class ViewController: UIViewController {

    //@IBOutlet weak var segmentOne: UISegmentedControl!
    
     
    @IBOutlet weak var segmentOne: UISegmentedControl!
    @IBOutlet weak var imgView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let arr = ["Google","Facebook","Instagram","Twitter"]
        let segmentSecond = UISegmentedControl.init(items: arr)
        segmentSecond.frame = CGRect(x: 5, y: 550, width: self.view.frame.size.width-10, height: 30)
        segmentSecond.backgroundColor = UIColor.cyan
        segmentSecond.selectedSegmentTintColor = UIColor.systemYellow
        segmentSecond.selectedSegmentIndex = 2
//        segmentSecond.layer.cornerRadius = 0
        segmentSecond.isMomentary = true
        segmentSecond.insertSegment(withTitle: "Whatsapp", at: 4, animated: true)
//        segmentSecond.setContentOffset(CGSize(width: 20, height: 20), forSegmentAt: 3)
//        segmentSecond.setWidth(150, forSegmentAt: 2)
//        segmentSecond.setImage(UIImage(named: "ee"), forSegmentAt: 2)
//        segmentSecond.setTitle("gooogle", forSegmentAt: 0)
//        segmentSecond.removeSegment(at: 2, animated: false)
//        segmentSecond.removeAllSegments()
//        segmentSecond.setEnabled(false, forSegmentAt: 3)
//        segmentSecond.isEnabledForSegment(at: 2)
//        segmentSecond.addTarget(self, action: Selector("changeColor") , for: .valueChanged)
        segmentSecond.addTarget(self, action: #selector(changeColor),for: .valueChanged)

        view.addSubview(segmentSecond)
        // Do any additional setup after loading the view.
        
    }
    
    @objc func changeColor(sender : UISegmentedControl)
    {
        switch sender.selectedSegmentIndex {
            case 0:
                imgView.image = UIImage(named: "google")
            case 1:
                imgView.image = UIImage(named: "facebook")
            case 2:
                imgView.image = UIImage(named: "instagram")
            case 3:
                imgView.image = UIImage(named: "twitter")
            case 4:
            imgView.image = UIImage(named: "whatsapp")
            default:
                break
            }
    }

}

